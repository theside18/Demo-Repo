package org.demo.controller;

import java.util.List;

import org.demo.model.Pet;
import org.demo.repo.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/pets")
public class PetController {
	
	@Autowired
	private PetRepository petReposotory;
	

	@GetMapping
	public List<Pet> getAllPets(){
		return petReposotory.findAll();
	}
	

	@PostMapping
	public Pet savePet(@RequestBody Pet pet) {
		return petReposotory.save(pet);
	}
	
	@DeleteMapping("/{id}")
	public void deletePet(@RequestBody int id) {
		petReposotory.deleteById(id);
	}
	
	
	
	

}
